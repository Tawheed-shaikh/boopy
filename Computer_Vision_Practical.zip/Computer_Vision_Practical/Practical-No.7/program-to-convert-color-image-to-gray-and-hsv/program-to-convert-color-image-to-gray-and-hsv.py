# Import commands for terminal:
# pip install opencv-python
# pip install numpy
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

def convert_color_image(image):
    """
    This function converts a color image to grayscale and HSV formats.
    Args:
    - image: Input color image in BGR format
    Returns:
    - gray_image: Image converted to grayscale
    - hsv_image: Image converted to HSV format
    """
    try:
        # Convert to grayscale
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Convert to HSV format
        hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        return gray_image, hsv_image

    except Exception as e:
        print(f"An error occurred during color conversion: {e}")

# Main code to load the image and apply color conversions
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")
        
        # Convert the color image
        gray_image, hsv_image = convert_color_image(image)

        # Display original, grayscale, and HSV images
        plt.figure(figsize=(15, 5))

        plt.subplot(1, 3, 1)
        plt.title('Original Image')
        plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.subplot(1, 3, 2)
        plt.title('Grayscale Image')
        plt.imshow(gray_image, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 3, 3)
        plt.title('HSV Image')
        plt.imshow(hsv_image)
        plt.axis('off')

        plt.show()

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

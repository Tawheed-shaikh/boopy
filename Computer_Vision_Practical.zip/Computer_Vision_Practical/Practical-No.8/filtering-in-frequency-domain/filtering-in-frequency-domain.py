# Import commands for terminal:
# pip install opencv-python
# pip install numpy
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

def low_pass_filter(image, cutoff):
    """
    Apply a Low Pass Filter (LPF) in the frequency domain.
    
    Args:
    - image: Input grayscale image
    - cutoff: Cutoff frequency for the LPF
    
    Returns:
    - filtered_image: Image after applying the LPF
    """
    try:
        # Compute the 2D DFT
        dft = np.fft.fft2(image)
        dft_shifted = np.fft.fftshift(dft)  # Shift zero frequency components to center

        # Create a mask for the low pass filter
        rows, cols = image.shape
        crow, ccol = rows // 2, cols // 2
        mask = np.zeros((rows, cols), np.float32)

        # Create a circular mask
        x = np.arange(0, rows)[:, None]  # Row indices
        y = np.arange(0, cols)  # Column indices
        distance = np.sqrt((x - crow)**2 + (y - ccol)**2)
        mask[distance <= cutoff] = 1  # Apply mask within the cutoff frequency

        # Apply the mask to the DFT
        filtered_dft_shifted = dft_shifted * mask

        # Inverse DFT to get the filtered image
        filtered_dft = np.fft.ifftshift(filtered_dft_shifted)
        filtered_image = np.fft.ifft2(filtered_dft)
        filtered_image = np.abs(filtered_image)  # Get the magnitude

        # Normalize to 0-255 for display
        filtered_image = cv2.normalize(filtered_image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

        return filtered_image

    except Exception as e:
        print(f"An error occurred while applying LPF: {e}")

def high_pass_filter(image, cutoff):
    """
    Apply a High Pass Filter (HPF) in the frequency domain.
    
    Args:
    - image: Input grayscale image
    - cutoff: Cutoff frequency for the HPF
    
    Returns:
    - filtered_image: Image after applying the HPF
    """
    try:
        # Compute the 2D DFT
        dft = np.fft.fft2(image)
        dft_shifted = np.fft.fftshift(dft)  # Shift zero frequency components to center

        # Create a mask for the high pass filter
        rows, cols = image.shape
        crow, ccol = rows // 2, cols // 2
        mask = np.ones((rows, cols), np.float32)

        # Create a circular mask for high pass filter
        x = np.arange(0, rows)[:, None]  # Row indices
        y = np.arange(0, cols)  # Column indices
        distance = np.sqrt((x - crow)**2 + (y - ccol)**2)
        mask[distance <= cutoff] = 0  # Set to 0 within the cutoff frequency

        # Apply the mask to the DFT
        filtered_dft_shifted = dft_shifted * mask

        # Inverse DFT to get the filtered image
        filtered_dft = np.fft.ifftshift(filtered_dft_shifted)
        filtered_image = np.fft.ifft2(filtered_dft)
        filtered_image = np.abs(filtered_image)  # Get the magnitude

        # Normalize to 0-255 for display
        filtered_image = cv2.normalize(filtered_image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

        return filtered_image

    except Exception as e:
        print(f"An error occurred while applying HPF: {e}")

# Main code to load the image and apply filters
if __name__ == "__main__":
    try:
        # Load the image (ensure there is an image named 'sample_image.jpg' in the same folder)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")

        # Convert to grayscale
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Apply Low Pass Filter
        lpf_cutoff = 30  # Define cutoff frequency for LPF
        lpf_image = low_pass_filter(gray_image, lpf_cutoff)

        # Apply High Pass Filter
        hpf_cutoff = 30  # Define cutoff frequency for HPF
        hpf_image = high_pass_filter(gray_image, hpf_cutoff)

        # Display original and filtered images
        plt.figure(figsize=(15, 5))

        plt.subplot(1, 3, 1)
        plt.title('Original Image')
        plt.imshow(gray_image, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 3, 2)
        plt.title('Low Pass Filtered Image')
        plt.imshow(lpf_image, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 3, 3)
        plt.title('High Pass Filtered Image')
        plt.imshow(hpf_image, cmap='gray')
        plt.axis('off')

        plt.show()

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib
# pip install scikit-image

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

def segment_image_watershed(image_path):
    """
    Perform image segmentation using the Watershed Transform.
    
    Args:
    - image_path: Path to the image file
    """
    try:
        # Load the image
        image = cv2.imread(image_path)
        
        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError(f"Error: Image not found at {image_path}. Please check the path.")

        # Convert the image to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Apply Gaussian blur to the image to reduce noise and improve segmentation
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)

        # Apply binary thresholding to get a binary image
        _, binary = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        # Create a kernel for morphological operations
        kernel = np.ones((3, 3), np.uint8)

        # Perform morphological operations to remove small noise
        opening = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=2)

        # Dilate the image to get the sure background
        sure_bg = cv2.dilate(opening, kernel, iterations=3)

        # Find the sure foreground area using distance transform
        dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
        _, sure_fg = cv2.threshold(dist_transform, 0.7 * dist_transform.max(), 255, 0)

        # Find unknown region by subtracting the sure foreground from the sure background
        unknown = cv2.subtract(sure_bg, np.uint8(sure_fg))

        # Label markers for the connected components
        _, markers = cv2.connectedComponents(np.uint8(sure_fg))

        # Add one to all the labels to distinguish unknown region
        markers = markers + 1
        markers[unknown == 255] = 0  # Mark the unknown region with zero

        # Apply the Watershed algorithm
        segmented_image = cv2.watershed(image, markers)

        # Mark the boundaries of the segmented regions in red
        image[segmented_image == -1] = [255, 0, 0]

        # Display the original and segmented images
        plt.figure(figsize=(12, 6))

        plt.subplot(1, 2, 1)
        plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        plt.title('Segmented Image')
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.imshow(binary, cmap='gray')
        plt.title('Binary Image')
        plt.axis('off')

        plt.tight_layout()
        plt.show()

    except FileNotFoundError as fnf_error:
        print(fnf_error)  # Print the error message for file not found
    except Exception as e:
        print(f"An unexpected error occurred: {e}")  # Catch any other exceptions

# Main code to execute the segmentation function
if __name__ == "__main__":
    try:
        # Specify the path to your image file
        image_path = 'sample_image.jpg'  # Change this to the path of your image
        segment_image_watershed(image_path)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

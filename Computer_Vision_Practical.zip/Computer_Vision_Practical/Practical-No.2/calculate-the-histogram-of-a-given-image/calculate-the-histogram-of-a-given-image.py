# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for array manipulation
import matplotlib.pyplot as plt  # Matplotlib for plotting histograms

# Function to calculate and display the histogram of an image
def calculate_histogram(image):
    """
    This function calculates and displays the histogram of the input image.
    Args:
    - image: Input image in BGR format
    Returns:
    None
    """
    try:
        # Convert the image to grayscale for histogram calculation
        grayscale_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Calculate the histogram
        histogram = cv2.calcHist([grayscale_image], [0], None, [256], [0, 256])

        # Plot the histogram
        plt.figure()
        plt.title("Grayscale Histogram")
        plt.xlabel("Pixel Values")
        plt.ylabel("Frequency")
        plt.plot(histogram)
        plt.xlim([0, 256])  # Limit x-axis to 256
        plt.show()

    except Exception as e:
        print(f"An error occurred while processing the image: {e}")

# Main code to load the image and calculate its histogram
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded properly
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")

        # Display the original image
        cv2.imshow('Original Image', image)

        # Calculate and display the histogram
        calculate_histogram(image)

        # Wait for the user to press a key and then close the display windows
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

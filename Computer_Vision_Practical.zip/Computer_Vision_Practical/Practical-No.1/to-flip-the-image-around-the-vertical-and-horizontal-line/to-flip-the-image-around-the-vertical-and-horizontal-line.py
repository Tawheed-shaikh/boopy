# Import commands for terminal:
# pip install opencv-python
# pip install numpy

# Import the necessary libraries
import cv2   # OpenCV for image processing
import numpy as np  # NumPy for array manipulation

# Function to flip an image around vertical and horizontal lines
def flip_image(image, flip_code):
    """
    This function flips the image based on the provided flip_code.
    Args:
    - image: Input image in BGR format
    - flip_code: Code specifying how to flip the image
        0: Flip around x-axis (horizontal flip)
        1: Flip around y-axis (vertical flip)
        -1: Flip around both axes (vertical and horizontal)
    Returns:
    - Flipped image
    """
    try:
        # Flip the image using the specified flip_code
        flipped_image = cv2.flip(image, flip_code)
        return flipped_image
    except Exception as e:
        print(f"An error occurred while flipping the image: {e}")
        return None

# Main code to load the image and flip it
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded properly
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")

        # Display the original image
        cv2.imshow('Original Image', image)

        # Flip the image around the horizontal axis (flip_code = 0)
        flipped_horizontally = flip_image(image, 0)
        if flipped_horizontally is not None:
            cv2.imshow('Flipped Horizontally (X-axis)', flipped_horizontally)

        # Flip the image around the vertical axis (flip_code = 1)
        flipped_vertically = flip_image(image, 1)
        if flipped_vertically is not None:
            cv2.imshow('Flipped Vertically (Y-axis)', flipped_vertically)

        # Flip the image around both axes (flip_code = -1)
        flipped_both = flip_image(image, -1)
        if flipped_both is not None:
            cv2.imshow('Flipped Horizontally and Vertically (Both axes)', flipped_both)

        # Save the flipped images to new files
        cv2.imwrite('flipped_horizontally.jpg', flipped_horizontally)
        cv2.imwrite('flipped_vertically.jpg', flipped_vertically)
        cv2.imwrite('flipped_both.jpg', flipped_both)

        # Wait for the user to press a key and then close the display windows
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
